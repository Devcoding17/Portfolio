# Data Engineer Portfolio - Replit Project Guide

## Overview

This is a modern, single-page portfolio website for a data engineer, built with a full-stack architecture. The application features a vibrant, playful design inspired by modern nutrition brands (like More Nutrition), adapted for a professional technical portfolio. It showcases skills, projects, and provides a contact form for potential opportunities.

The portfolio emphasizes visual appeal with decorative SVG elements, animated counters, scroll-based reveals, and a video background hero section, while maintaining professional credibility appropriate for a data engineering role.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework & Build Tool**
- **React 18** with TypeScript for component-based UI development
- **Vite** as the build tool and dev server for fast hot module replacement
- **Wouter** for lightweight client-side routing (single-page application)

**Design System**
- **shadcn/ui** component library (New York style variant) with Radix UI primitives
- **Tailwind CSS** for utility-first styling with custom design tokens
- **Google Fonts**: Space Grotesk (headings), Inter (body), JetBrains Mono (code)
- Custom CSS variables for theming (light mode with potential dark mode support)
- Design philosophy: Modern, energetic, playful yet professional with decorative SVG elements

**State Management & Data Fetching**
- **TanStack Query (React Query)** for server state management and API calls
- Custom `queryClient` configuration with infinite stale time and disabled refetching
- Form handling via `react-hook-form` with `@hookform/resolvers` for validation

**UI Features**
- Intersection Observer-based scroll animations (ScrollReveal component)
- Animated counters with viewport detection
- Video background in hero section
- Responsive navigation with mobile menu
- Toast notifications for user feedback

### Backend Architecture

**Server Framework**
- **Express.js** server with TypeScript
- Custom middleware for request logging with timing and response capture
- JSON body parsing with raw body preservation for webhook compatibility

**Development Environment**
- Vite middleware mode for development with HMR
- Separate build process: Vite for frontend, esbuild for backend
- Replit-specific plugins for error overlays, cartographer, and dev banner

**API Structure**
- RESTful endpoints under `/api` namespace
- `/api/contact` - POST endpoint for contact form submissions
- `/api/contacts` - GET endpoint for retrieving all contacts (admin)
- Zod schema validation using `drizzle-zod` for request validation

### Data Storage Solutions

**Database Configuration**
- **PostgreSQL** via `@neondatabase/serverless` driver
- **Drizzle ORM** for type-safe database operations and migrations
- Connection string via `DATABASE_URL` environment variable
- Migration files in `./migrations` directory

**Database Schema**
Two primary tables defined in `shared/schema.ts`:

1. **users** table:
   - UUID primary key with auto-generation
   - Username (unique, required)
   - Password (required)
   - Currently unused but prepared for future authentication

2. **contacts** table:
   - UUID primary key with auto-generation
   - Name, email, message fields (all required)
   - CreatedAt timestamp with auto-default
   - Stores contact form submissions

**Storage Abstraction**
- `IStorage` interface defines storage contract
- `MemStorage` in-memory implementation for development/testing
- Supports user and contact CRUD operations
- Design allows easy swapping between in-memory and database implementations

### Component Architecture

**Page Structure**
- Single-page application with one main route (`/`)
- Home page composed of six major sections:
  1. Navigation (sticky header)
  2. HeroSection (full-viewport video background)
  3. AboutSection (introduction and background)
  4. SkillsSection (technical skills grid)
  5. ProjectsSection (portfolio projects)
  6. ContactSection (contact form)
  7. Footer

**Reusable Components**
- DecorativeArrow - SVG arrows for visual flow
- DecorativeUnderline - Hand-drawn style underlines
- AnimatedCounter - Intersection Observer-based number animations
- ScrollReveal - Wrapper for scroll-triggered animations

**UI Component Library**
Comprehensive shadcn/ui components including:
- Forms: Input, Textarea, Button, Label, Checkbox, Select
- Layout: Card, Separator, Accordion, Tabs
- Overlays: Dialog, Sheet, Popover, Tooltip
- Feedback: Toast, Alert, Progress
- Navigation: Navigation Menu, Breadcrumb

### Path Aliases & Module Resolution

Configured via `tsconfig.json` and `vite.config.ts`:
- `@/*` → `client/src/*` (frontend components/utilities)
- `@shared/*` → `shared/*` (shared schemas/types)
- `@assets/*` → `attached_assets/*` (static assets like videos)

## External Dependencies

### Core Libraries
- **React ecosystem**: react, react-dom, react-router via wouter
- **Build tools**: vite, esbuild, typescript, tsx
- **Backend**: express, drizzle-orm, @neondatabase/serverless
- **Validation**: zod, drizzle-zod, @hookform/resolvers

### UI & Styling
- **Radix UI**: 20+ primitive components (@radix-ui/react-*)
- **Styling**: tailwindcss, postcss, autoprefixer, clsx, tailwind-merge
- **Utilities**: class-variance-authority for component variants
- **Icons**: lucide-react
- **Fonts**: Google Fonts (Space Grotesk, Inter, JetBrains Mono)

### State & Data Management
- **@tanstack/react-query** v5 for server state
- **react-hook-form** for form handling
- **cmdk** for command palette support
- **date-fns** for date formatting

### Replit Integration
- @replit/vite-plugin-runtime-error-modal
- @replit/vite-plugin-cartographer (dev only)
- @replit/vite-plugin-dev-banner (dev only)

### Session & Storage
- **connect-pg-simple** for PostgreSQL session store
- In-memory fallback storage implementation included

### Additional UI Libraries
- **embla-carousel-react** for carousels
- **vaul** for drawer component
- **react-day-picker** for calendar/date selection
- **recharts** for data visualization (prepared but not actively used)

### Development Tools
- **drizzle-kit** for database migrations
- TypeScript for type safety across full stack
- ESLint/Prettier configuration implied by project structure