import DecorativeArrow from '../DecorativeArrow';

export default function DecorativeArrowExample() {
  return (
    <div className="p-8 space-y-8">
      <div>
        <h3 className="text-lg font-semibold mb-4">Down Arrow</h3>
        <DecorativeArrow direction="down" className="w-20 h-20" />
      </div>
      <div>
        <h3 className="text-lg font-semibold mb-4">Curve Right</h3>
        <DecorativeArrow direction="curve-right" className="w-32 h-8" />
      </div>
    </div>
  );
}