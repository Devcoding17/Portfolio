import AnimatedCounter from '../AnimatedCounter';

export default function AnimatedCounterExample() {
  return (
    <div className="p-8 space-y-8">
      <div className="text-center">
        <AnimatedCounter 
          end={100} 
          suffix="%" 
          className="text-4xl font-bold text-primary"
        />
        <p className="text-muted-foreground mt-2">Completion Rate</p>
      </div>
      <div className="text-center">
        <AnimatedCounter 
          end={50} 
          suffix="+" 
          className="text-4xl font-bold text-accent"
        />
        <p className="text-muted-foreground mt-2">Projects</p>
      </div>
    </div>
  );
}