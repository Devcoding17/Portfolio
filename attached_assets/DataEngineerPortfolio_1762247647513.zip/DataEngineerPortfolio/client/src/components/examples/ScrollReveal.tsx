import ScrollReveal from '../ScrollReveal';
import { Card } from '@/components/ui/card';

export default function ScrollRevealExample() {
  return (
    <div className="p-8 space-y-8">
      <ScrollReveal>
        <Card className="p-6">
          <h3 className="text-xl font-bold">First Reveal</h3>
          <p className="text-muted-foreground">This appears when scrolled into view</p>
        </Card>
      </ScrollReveal>
      <ScrollReveal delay={200}>
        <Card className="p-6">
          <h3 className="text-xl font-bold">Second Reveal (Delayed)</h3>
          <p className="text-muted-foreground">This appears with a 200ms delay</p>
        </Card>
      </ScrollReveal>
    </div>
  );
}