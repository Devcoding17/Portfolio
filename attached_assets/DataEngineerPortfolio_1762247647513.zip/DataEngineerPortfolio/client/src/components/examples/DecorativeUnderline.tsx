import DecorativeUnderline from '../DecorativeUnderline';

export default function DecorativeUnderlineExample() {
  return (
    <div className="p-8 space-y-8">
      <div>
        <h2 className="text-2xl font-bold mb-2">Wavy Underline</h2>
        <DecorativeUnderline style="wavy" />
      </div>
      <div>
        <h2 className="text-2xl font-bold mb-2">Zigzag Underline</h2>
        <DecorativeUnderline style="zigzag" />
      </div>
    </div>
  );
}