import { ArrowDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import heroVideo from "@assets/hero-bg_1762239108990.mp4";

export default function HeroSection() {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    element?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section className="relative h-screen min-h-[600px] flex items-center justify-center overflow-hidden">
      <video
        autoPlay
        loop
        muted
        playsInline
        className="absolute inset-0 w-full h-full object-cover"
        data-testid="video-hero-background"
      >
        <source src={heroVideo} type="video/mp4" />
      </video>
      
      <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/50 to-black/70" />
      
      <div className="relative z-10 max-w-6xl mx-auto px-6 text-center">
        <div className="space-y-6">
          <div className="inline-flex items-center gap-3 px-4 py-2 rounded-full bg-primary/10 backdrop-blur-md border border-primary/20">
            <div className="w-2 h-2 rounded-full bg-primary animate-pulse" />
            <span className="text-sm font-medium text-white" data-testid="text-status">Available for Opportunities</span>
          </div>
          
          <h1 className="text-5xl md:text-7xl lg:text-8xl font-bold text-white font-heading leading-tight" data-testid="text-hero-title">
            Data Engineer.
            <br />
            <span className="text-primary">Problem Solver.</span>
            <br />
            Story Teller.
          </h1>
          
          <p className="text-xl md:text-2xl text-white/90 max-w-3xl mx-auto font-light" data-testid="text-hero-subtitle">
            Turning raw data into actionable insights through scalable pipelines and intelligent analytics
          </p>
          
          <div className="flex flex-wrap gap-4 justify-center pt-4">
            <Button 
              size="lg" 
              className="bg-primary hover-elevate active-elevate-2 text-lg px-8"
              onClick={() => scrollToSection("projects")}
              data-testid="button-view-work"
            >
              View My Work
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="bg-white/10 hover-elevate active-elevate-2 backdrop-blur-md border-white/30 text-white text-lg px-8"
              onClick={() => scrollToSection("contact")}
              data-testid="button-contact"
            >
              Get In Touch
            </Button>
          </div>
          
          <div className="flex gap-8 justify-center pt-8 text-white/80">
            <div className="text-center">
              <div className="text-3xl md:text-4xl font-bold text-primary" data-testid="text-stat-projects">5+</div>
              <div className="text-sm md:text-base">Projects</div>
            </div>
            <div className="text-center">
              <div className="text-3xl md:text-4xl font-bold text-primary" data-testid="text-stat-skills">10+</div>
              <div className="text-sm md:text-base">Skills</div>
            </div>
            <div className="text-center">
              <div className="text-3xl md:text-4xl font-bold text-primary" data-testid="text-stat-cert">3+</div>
              <div className="text-sm md:text-base">Certifications</div>
            </div>
          </div>
        </div>
      </div>
      
      <button 
        onClick={() => scrollToSection("about")}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 text-white/60 hover:text-white transition-colors animate-bounce"
        data-testid="button-scroll-down"
        aria-label="Scroll down"
      >
        <ArrowDown size={32} />
      </button>
    </section>
  );
}