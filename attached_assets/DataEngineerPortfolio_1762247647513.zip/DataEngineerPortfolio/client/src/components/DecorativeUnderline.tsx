interface DecorativeUnderlineProps {
  className?: string;
  style?: 'wavy' | 'straight' | 'zigzag';
}

export default function DecorativeUnderline({ className = "", style = 'wavy' }: DecorativeUnderlineProps) {
  const paths = {
    wavy: "M 0 15 Q 25 5, 50 15 T 100 15",
    straight: "M 0 10 L 100 10",
    zigzag: "M 0 15 L 20 5 L 40 15 L 60 5 L 80 15 L 100 5",
  };

  return (
    <svg 
      className={`w-full h-4 ${className}`}
      viewBox="0 0 100 20"
      preserveAspectRatio="none"
    >
      <path 
        d={paths[style]} 
        stroke="currentColor" 
        strokeWidth="2" 
        fill="none"
        className="text-primary/30"
      />
    </svg>
  );
}