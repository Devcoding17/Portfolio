import { Heart, Github, Linkedin, Mail, ArrowUp } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Footer() {
  const currentYear = new Date().getFullYear();

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <footer className="relative bg-background border-t border-border py-12 overflow-hidden">
      {/* Decorative Elements */}
      <div className="absolute top-0 left-1/3 w-64 h-64 bg-primary/5 rounded-full blur-3xl" />
      <div className="absolute bottom-0 right-1/3 w-72 h-72 bg-accent/5 rounded-full blur-3xl" />
      
      <div className="relative max-w-6xl mx-auto px-6">
        <div className="grid md:grid-cols-4 gap-8 mb-10">
          <div className="md:col-span-2">
            <h3 className="text-2xl font-bold font-heading mb-4" data-testid="text-footer-brand">
              Data<span className="text-primary">Engineer</span>
            </h3>
            <p className="text-muted-foreground text-sm max-w-md leading-relaxed mb-4" data-testid="text-footer-tagline">
              Building the future of data, one pipeline at a time. Transforming complex data challenges into elegant, scalable solutions.
            </p>
            <div className="flex gap-3">
              <a
                href="https://github.com/yourusername"
                target="_blank"
                rel="noopener noreferrer"
                className="p-3 rounded-lg hover-elevate active-elevate-2 bg-muted transition-all"
                aria-label="GitHub"
                data-testid="link-footer-github"
              >
                <Github className="w-5 h-5" />
              </a>
              <a
                href="https://linkedin.com/in/yourprofile"
                target="_blank"
                rel="noopener noreferrer"
                className="p-3 rounded-lg hover-elevate active-elevate-2 bg-muted transition-all"
                aria-label="LinkedIn"
                data-testid="link-footer-linkedin"
              >
                <Linkedin className="w-5 h-5" />
              </a>
              <a
                href="mailto:your.email@example.com"
                className="p-3 rounded-lg hover-elevate active-elevate-2 bg-muted transition-all"
                aria-label="Email"
                data-testid="link-footer-email"
              >
                <Mail className="w-5 h-5" />
              </a>
            </div>
          </div>

          <div>
            <h4 className="font-bold mb-4 text-lg" data-testid="text-footer-quick-links">Quick Links</h4>
            <ul className="space-y-3 text-sm">
              {["About", "Skills", "Projects", "Contact"].map((link) => (
                <li key={link}>
                  <button
                    onClick={() => {
                      const element = document.getElementById(link.toLowerCase());
                      element?.scrollIntoView({ behavior: "smooth" });
                    }}
                    className="text-muted-foreground hover:text-primary transition-colors hover-elevate px-2 py-1 rounded"
                    data-testid={`link-footer-${link.toLowerCase()}`}
                  >
                    {link}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-bold mb-4 text-lg" data-testid="text-footer-tech">Built With</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>React + TypeScript</li>
              <li>Tailwind CSS</li>
              <li>Express.js</li>
              <li>Vite</li>
            </ul>
          </div>
        </div>

        <div className="pt-8 border-t border-border flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="flex items-center gap-2 text-sm text-muted-foreground" data-testid="text-footer-copyright">
            © {currentYear} Built with <Heart className="w-4 h-4 text-primary fill-primary animate-pulse" /> and lots of data
          </p>
          
          <Button
            variant="outline"
            size="sm"
            onClick={scrollToTop}
            className="hover-elevate"
            data-testid="button-back-to-top"
          >
            <ArrowUp className="w-4 h-4 mr-2" />
            Back to Top
          </Button>
        </div>
      </div>
    </footer>
  );
}