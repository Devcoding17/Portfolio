interface DecorativeArrowProps {
  className?: string;
  direction?: 'down' | 'up' | 'curve-right' | 'curve-left';
}

export default function DecorativeArrow({ className = "", direction = 'down' }: DecorativeArrowProps) {
  const paths = {
    down: "M 50 10 L 50 70 M 30 50 L 50 70 L 70 50",
    up: "M 50 70 L 50 10 M 30 30 L 50 10 L 70 30",
    'curve-right': "M 10 20 Q 50 5, 90 20",
    'curve-left': "M 90 20 Q 50 5, 10 20",
  };

  return (
    <svg 
      className={`text-primary/40 ${className}`}
      viewBox="0 0 100 80"
      fill="none"
    >
      <path 
        d={paths[direction]} 
        stroke="currentColor" 
        strokeWidth="3" 
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}